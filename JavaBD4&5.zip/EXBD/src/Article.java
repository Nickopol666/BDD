
public class Article {
	private int idUser;
	private String description;
	private String marque;
	private double prixUnitaire;
	private int idCategory;
	
	public Article(int idUser,String description,String marque,double prixUnitaire,int idCategory) {
		setIdUser (idUser);
		setDescription(description);
		setMarque(marque);
		setPrixUnitaire(prixUnitaire);
		setIdCategory(idCategory);
	}
	public Article(String description,String marque,double prixUnitaire,int idCategory) {
		setDescription(description);
		setMarque(marque);
		setPrixUnitaire(prixUnitaire);
		setIdCategory(idCategory);
	}
	/**
	 * @return the idUser
	 */
	public int getIdUser() {
		return idUser;
	}

	/**
	 * @param idUser the idUser to set
	 */
	public void setIdUser(int idUser) {
		this.idUser = idUser;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the marque
	 */
	public String getMarque() {
		return marque;
	}

	/**
	 * @param marque the marque to set
	 */
	public void setMarque(String marque) {
		this.marque = marque;
	}

	/**
	 * @return the prixUnitaire
	 */
	public double getPrixUnitaire() {
		return prixUnitaire;
	}

	/**
	 * @param prixUnitaire the prixUnitaire to set
	 */
	public void setPrixUnitaire(double prixUnitaire) {
		this.prixUnitaire = prixUnitaire;
	}

	/**
	 * @return the idCategory
	 */
	public int getIdCategory() {
		return idCategory;
	}

	/**
	 * @param idCategory the idCategory to set
	 */
	public void setIdCategory(int idCategory) {
		this.idCategory = idCategory;
	}

	@Override
	public String toString() {
		return "Article [idUser=" + idUser + ", description=" + description + ", marque=" + marque + ", prixUnitaire="
				+ prixUnitaire + ", idCategory=" + idCategory + "]";
	}

}