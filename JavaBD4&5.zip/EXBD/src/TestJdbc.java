import java.util.ArrayList;
import java.util.Hashtable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
public class TestJdbc {
	
	public static void main(String [] args) throws Exception{
		ArrayList<Article> articles = new ArrayList<Article>();
		
		//CreateConfigFile Test = new CreateConfigFile(null, null, null, null);
//		try {
//			("org.mariadb.jdbc.Driver");
//		}
//		catch(ClassNotFoundException e) {
//			e.printStackTrace();
//		}
//		String url ="jdbc:mariadb://localhost:3306/shop";
//		String login ="root";
//		String password ="fms2023";
		
	//	ArticleDao Insertion = new ArticleDao();
		//ReadPropertiesFileTest var =new ReadPropertiesFileTest();
		Properties prop = ReadPropertiesFileTest.readPropertiesFile("C:\\Users\\GuyauN\\eclipse-workspace\\EXBD\\src\\InfoDeConnexion");
		Class.forName(prop.getProperty("db.driver.class"));
		String url = prop.getProperty("db.url");
		String password = prop.getProperty("db.password");
		String login = prop.getProperty("db.login");
		//System.out.println("prop");
		new ReadPropertiesFileTest();
		try(Connection connection = DriverManager.getConnection(url,login,password)){
			String strSql ="SELECT * FROM T_Articles";
			try(Statement statement = connection.createStatement()){
				try(ResultSet resultSet = statement.executeQuery(strSql)){
					while(resultSet.next()) {
						int rsIdUser = resultSet.getInt(1);
						String rsDescription= resultSet.getString(2);
						String rsMarque = resultSet.getString(3);
						double rsPrixUnitaire = resultSet.getDouble(4);
						int rsIdCat = resultSet.getInt(5);
						articles.add((new Article(rsIdUser,rsDescription,rsMarque,rsPrixUnitaire,rsIdCat)));
				}
			}
		}
			
		
		for(Article a : articles)
			System.out.println(a.getIdUser()+a.getDescription()+a.getMarque()+a.getPrixUnitaire()+a.getIdCategory());
	}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}

}
