
public class CreateConfigFile {
	public String driver;
	public String url;
	public String login;
	public String pswd;
	
	public CreateConfigFile(String driver, String url,String login,String pswd) {
		setDriver(driver);
		setUrl(url);
		setLogin(login);
		setPswd(pswd);
	}

	/**
	 * @return the driver
	 */
	public String getDriver() {
		return driver;
	}

	/**
	 * @param driver the driver to set
	 */
	public void setDriver(String driver) {
		this.driver = "org.mariadb.jdbc.Driver";
	}

	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		this.url = "jdbc:mariadb://localhost:3306/Shop";
	}

	/**
	 * @return the login
	 */
	public String getLogin() {
		return login;
	}

	/**
	 * @param login the login to set
	 */
	public void setLogin(String login) {
		this.login = "root";
	}

	/**
	 * @return the pswd
	 */
	public String getPswd() {
		return pswd;
	}

	/**
	 * @param pswd the pswd to set
	 */
	public void setPswd(String pswd) {
		this.pswd = "fms2023";
	}
	
}
