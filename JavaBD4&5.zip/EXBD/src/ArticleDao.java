import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;

public class ArticleDao implements Dao<Article>{
	
	public void create(Article obj) {
		try (Statement statement = connection.createStatement()){
			String str ="INSERT INTO t_articles (Description,Brand,UnitaryPrice,IdCategory)"
					+"VALUES('"+ obj.getDescription()+"','"+ obj.getMarque()+"',"+obj.getPrixUnitaire()+"',"+obj.getIdCategory()+");";
			int row = statement.executeUpdate(str);
			if(row == 1)	System.out.println("insertion ok");		
		}catch ( SQLException e) {
			e.printStackTrace();
		}
		
		
	}
}
