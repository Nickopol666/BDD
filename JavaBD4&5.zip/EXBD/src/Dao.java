import java.sql.Connection;
import java.util.ArrayList;

public interface Dao<T> {
	public void create(Article job);
	public Connection connection = BddConnection.getConnection();
	public T read(int id);
	public boolean update(T obj);
	public boolean delete(T obj);
	public ArrayList<T> readAll();

}
